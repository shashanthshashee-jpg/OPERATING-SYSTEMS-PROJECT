# Deadlock OS - Linux Deadlock Detection and Resource Management System
OSSP (25CS2104E) project. Plain C, POSIX/Linux APIs, runs on Ubuntu.

## Build and run
    sudo apt install build-essential     # one time
    make                                 # builds ./deadlockos
    ./deadlockos                         # interactive shell, type: help
    make demo                            # automatic deadlock -> detect -> recover demo

## How it works
Each simulated process is a real forked Linux process. It receives instructions over a pipe,
sends its resource requests to the manager over another pipe, and really blocks until the
request is granted. The manager keeps allocation / request matrices, detects circular wait,
and recovers by sending SIGTERM to a victim.

## Course outcomes -> code
| CO | Where | Commands |
|----|-------|----------|
| CO-1 OS as service layer | src/main.c (shell), system calls everywhere | sys, sh, help |
| CO-2 Processes | src/proc.c: fork, waitpid, states, exit codes | spawn, ps, exit, kill |
| CO-3 IPC and signals | src/proc.c: pipes, FIFO, sigaction, process group | req, rel, fifo, kill, killall |
| CO-4 Memory | src/mem.c: mmap shared board, malloc/calloc, COW, page faults | maps, mem, cow, faults |
| CO-5 Files | src/fileio.c: open/read/write/stat, O_APPEND log, scenario files | save, load, stat, log |
| CO-6 Concurrency | src/sync.c, src/proc.c: threads, mutex, condvar, semaphore, detection, Banker's | detect, banker, recover, race |

## Example session
    res 3 1 1 1
    spawn / spawn / spawn
    req P0 R0 1 / req P1 R1 1 / req P2 R2 1
    req P0 R1 1 / req P1 R2 1 / req P2 R0 1     (circular wait)
    ps / show / detect / recover
Offline analysis: `load scenarios/deadlock.txt`, `detect`, `banker`; `load scenarios/safe.txt`, `banker`.
