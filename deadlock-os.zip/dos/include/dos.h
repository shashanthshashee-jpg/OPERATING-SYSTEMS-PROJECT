/* dos.h - shared declarations for Deadlock OS (CO-1 .. CO-6) */
#ifndef DOS_H
#define DOS_H
#define _GNU_SOURCE
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>
#include <signal.h>
#include <stdarg.h>
#include <pthread.h>
#include <semaphore.h>
#include <sys/types.h>
#include <sys/wait.h>
#include <sys/stat.h>
#include <sys/mman.h>
#define MAXP 8
#define W(fd, b, n) do { ssize_t _r = write(fd, b, n); (void)_r; } while (0)
enum { S_FREE, S_RUN, S_WAIT, S_DONE, S_KILLED, S_VIRT };
typedef struct { volatile int st[MAXP]; } Board;      /* shared via mmap (CO-4) */
typedef struct {
    int nres, np; int *total, *alloc, *req, *max;     /* dynamic matrices (CO-4) */
    pid_t pid[MAXP], pgid; int down[MAXP], up[MAXP];  /* pipes to each process (CO-3) */
    pthread_t th[MAXP]; int killed[MAXP];
    pthread_mutex_t mu; pthread_cond_t cv; sem_t slots; /* synchronization (CO-6) */
} Sys;
extern Sys G; extern Board *B; extern const char *SN[];
#define AL(p, r) G.alloc[(p) * G.nres + (r)]
#define RQ(p, r) G.req[(p) * G.nres + (r)]
#define MX(p, r) G.max[(p) * G.nres + (r)]
/* fileio.c (CO-5) */ void log_open(void); void dlog(const char *fmt, ...);
int save_state(const char *f); int load_state(const char *f); void stat_file(const char *f);
/* mem.c (CO-4) */ void board_init(void); void show_maps(void); void show_mem(void);
void cow_demo(void); void fault_demo(void);
/* sync.c (CO-6) */ int avail_of(int r); int detect(int *dead); int banker(void);
void race_demo(void); void show_state(void);
/* proc.c (CO-2, CO-3) */ void sys_reset(int nres, const int *units); int spawn(void);
void send_do(int p, const char *op, int r, int n); void finish(int p, int killed);
void kill_all(void); void ps(void); void fifo_demo(void); void sig_init(void);
#endif
