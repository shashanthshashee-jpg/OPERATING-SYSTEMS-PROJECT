/* sync.c - CO-6: detection, Banker's algorithm, race condition vs mutex */
#include "dos.h"
#include <sched.h>
int avail_of(int r) { int s = G.total[r]; for (int p = 0; p < G.np; p++) s -= AL(p, r); return s; }
static int gone(int p) { return B->st[p] == S_DONE || B->st[p] == S_KILLED; }

int detect(int *dead) {                    /* multi-instance deadlock detection */
    pthread_mutex_lock(&G.mu);
    int m = G.nres, w[16], fin[MAXP], cnt = 0, ch = 1;
    for (int r = 0; r < m; r++) w[r] = avail_of(r);
    for (int p = 0; p < G.np; p++) {
        fin[p] = gone(p);
        if (!fin[p]) { fin[p] = 1; for (int r = 0; r < m; r++) if (AL(p, r)) fin[p] = 0; }
    }
    while (ch) {
        ch = 0;
        for (int p = 0; p < G.np; p++) {
            if (fin[p]) continue;
            int ok = 1; for (int r = 0; r < m; r++) if (RQ(p, r) > w[r]) ok = 0;
            if (!ok) continue;
            for (int r = 0; r < m; r++) w[r] += AL(p, r);
            fin[p] = 1; ch = 1;
        }
    }
    for (int p = 0; p < G.np; p++) { dead[p] = !fin[p]; cnt += dead[p]; }
    pthread_mutex_unlock(&G.mu);
    return cnt;
}

int banker(void) {                         /* safe-state check: Need = Max - Alloc */
    pthread_mutex_lock(&G.mu);
    int m = G.nres, w[16], fin[MAXP], seq[MAXP], ns = 0, ch = 1;
    for (int r = 0; r < m; r++) w[r] = avail_of(r);
    for (int p = 0; p < G.np; p++) fin[p] = gone(p);
    while (ch) {
        ch = 0;
        for (int p = 0; p < G.np; p++) {
            if (fin[p]) continue;
            int ok = 1;
            for (int r = 0; r < m; r++) {
                int mx = MX(p, r) > AL(p, r) + RQ(p, r) ? MX(p, r) : AL(p, r) + RQ(p, r);
                if (mx - AL(p, r) > w[r]) ok = 0;
            }
            if (!ok) continue;
            for (int r = 0; r < m; r++) w[r] += AL(p, r);
            fin[p] = 1; seq[ns++] = p; ch = 1;
        }
    }
    int safe = 1; for (int p = 0; p < G.np; p++) if (!fin[p]) safe = 0;
    pthread_mutex_unlock(&G.mu);
    if (safe) { printf("  SAFE state. Safe sequence:"); for (int i = 0; i < ns; i++) printf(" P%d%s", seq[i], i < ns - 1 ? " ->" : ""); puts(""); }
    else puts("  UNSAFE state: no order lets every process finish");
    return safe;
}

void show_state(void) {
    pthread_mutex_lock(&G.mu);
    printf("  %-5s %-*s | %-*s | state\n", "proc", G.nres * 2, "Alloc", G.nres * 2, "Request");
    for (int p = 0; p < G.np; p++) {
        printf("  P%-4d ", p);
        for (int r = 0; r < G.nres; r++) printf("%d ", AL(p, r));
        printf("| ");
        for (int r = 0; r < G.nres; r++) printf("%d ", RQ(p, r));
        printf("| %s\n", SN[B->st[p]]);
    }
    printf("  total:"); for (int r = 0; r < G.nres; r++) printf(" R%d=%d", r, G.total[r]);
    printf("   available:"); for (int r = 0; r < G.nres; r++) printf(" R%d=%d", r, avail_of(r));
    puts(""); pthread_mutex_unlock(&G.mu);
}

static volatile long cnt; static pthread_mutex_t rm = PTHREAD_MUTEX_INITIALIZER; static int use_lock;
static void *inc(void *a) {
    (void)a;
    for (int i = 0; i < 500000; i++) {
        if (use_lock) pthread_mutex_lock(&rm);
        long t = cnt;                      /* read ... */
        if ((i & 255) == 0) sched_yield(); /* another thread may run here */
        cnt = t + 1;                       /* ... modify ... write */
        if (use_lock) pthread_mutex_unlock(&rm);
    }
    return NULL;
}
void race_demo(void) {                     /* shared counter: race vs mutual exclusion */
    pthread_t t[2];
    for (use_lock = 0; use_lock < 2; use_lock++) {
        cnt = 0;
        pthread_create(&t[0], NULL, inc, NULL); pthread_create(&t[1], NULL, inc, NULL);
        pthread_join(t[0], NULL); pthread_join(t[1], NULL);
        printf("  %s: expected 1000000, got %ld\n", use_lock ? "with mutex   " : "without mutex", cnt);
    }
}
