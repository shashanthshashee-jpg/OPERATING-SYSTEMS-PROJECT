/* main.c - CO-1: the command-line shell (user space) that drives the whole system */
#include "dos.h"
#include <sys/syscall.h>
#include <sys/utsname.h>
Sys G = { .mu = PTHREAD_MUTEX_INITIALIZER, .cv = PTHREAD_COND_INITIALIZER };
Board *B;

static int pn(const char *s, char c) { return (s && (s[0] == c || s[0] == c + 32)) ? atoi(s + 1) : -1; }
static int okp(int p) { return p >= 0 && p < G.np; }

static void help(void) {
    puts("  res <n> <u0> <u1>..  define n resource types and their units   spawn  create a process (fork)\n"
         "  req|rel Pn Rm k      request / release k units of Rm            exit Pn  let Pn exit normally\n"
         "  claim Pn Rm k        set Max claim (for Banker's)               kill Pn  terminate Pn (SIGTERM)\n"
         "  ps | show            process table | allocation matrices       killall  signal the whole group\n"
         "  detect | banker      deadlock detection | safe-state check      recover  detect + kill a victim\n"
         "  save f | load f     write / read a scenario file                log      show deadlockos.log\n"
         "  stat f               inode information                          sh <cmd> run a Linux command\n"
         "  sys | maps | mem     syscalls & kernel info | address space | memory use\n"
         "  cow | faults         copy-on-write | demand paging demo\n"
         "  race | fifo          race condition vs mutex | named pipe demo\n"
         "  demo | help | quit");
}

static int exec_line(char *line);
static void demo(void) {
    static const char *D[] = { "res 3 1 1 1", "spawn", "spawn", "spawn", "req P0 R0 1", "req P1 R1 1", "req P2 R2 1",
        "req P0 R1 1", "req P1 R2 1", "req P2 R0 1", "ps", "show", "detect", "recover", "ps", "show", "killall" };
    for (unsigned i = 0; i < sizeof D / sizeof *D; i++) {
        char b[64]; snprintf(b, sizeof b, "%s", D[i]);
        printf("dos> %s\n", D[i]); exec_line(b); usleep(300000);
    }
}

static void print_log(void) {
    char b[4096]; int fd = open("deadlockos.log", O_RDONLY); ssize_t k;
    if (fd < 0) { puts("  no log yet"); return; }
    while ((k = read(fd, b, sizeof b)) > 0) fwrite(b, 1, k, stdout);
    close(fd);
}

static void run_sh(char **av, int ac) {    /* command execution journey: fork + exec + wait */
    char cmd[200] = ""; for (int i = 1; i < ac; i++) { strcat(cmd, av[i]); strcat(cmd, " "); }
    fflush(stdout); pid_t c = fork();
    if (c == 0) { execl("/bin/sh", "sh", "-c", cmd, (char *)NULL); _exit(127); }
    int st; waitpid(c, &st, 0); printf("  [exit status %d]\n", WEXITSTATUS(st));
}

static int exec_line(char *line) {
    char *av[12] = {0}; int ac = 0;
    for (char *t = strtok(line, " \t\n"); t && ac < 11; t = strtok(NULL, " \t\n")) av[ac++] = t;
    if (!ac) return 0;
    const char *c = av[0]; int dead[MAXP];
    if (!strcmp(c, "quit")) return 1;
    else if (!strcmp(c, "help")) help();
    else if (!strcmp(c, "res")) {
        int n = ac > 1 ? atoi(av[1]) : 0, u[16];
        if (n < 1 || n > 16 || ac < n + 2) { puts("  usage: res <n> <units of R0> ... <units of Rn-1>"); return 0; }
        for (int i = 0; i < n; i++) u[i] = atoi(av[2 + i]);
        sys_reset(n, u); dlog("defined %d resource types", n);
    }
    else if (!strcmp(c, "spawn")) spawn();
    else if (!strcmp(c, "req") || !strcmp(c, "rel")) {
        int p = pn(av[1], 'P'), r = pn(av[2], 'R'), n = ac > 3 ? atoi(av[3]) : 1;
        if (!okp(p) || r < 0 || r >= G.nres || n < 1) puts("  usage: req|rel Pn Rm [k]");
        else if (B->st[p] != S_RUN) printf("  P%d is %s and cannot take new commands\n", p, SN[B->st[p]]);
        else { send_do(p, c[1] == 'e' && c[2] == 'q' ? "REQ" : "REL", r, n); usleep(60000); }
    }
    else if (!strcmp(c, "claim")) {
        int p = pn(av[1], 'P'), r = pn(av[2], 'R'), n = ac > 3 ? atoi(av[3]) : 0;
        if (!okp(p) || r < 0 || r >= G.nres) puts("  usage: claim Pn Rm k"); else MX(p, r) = n;
    }
    else if (!strcmp(c, "exit")) { int p = pn(av[1], 'P'); if (okp(p) && B->st[p] == S_RUN) finish(p, 0); else puts("  usage: exit Pn (process must be running)"); }
    else if (!strcmp(c, "kill")) { int p = pn(av[1], 'P'); if (okp(p)) finish(p, 1); else puts("  usage: kill Pn"); }
    else if (!strcmp(c, "killall")) kill_all();
    else if (!strcmp(c, "ps")) ps();
    else if (!strcmp(c, "show")) { if (G.nres) show_state(); else puts("  no resources defined"); }
    else if (!strcmp(c, "detect") || !strcmp(c, "recover")) {
        if (!G.nres) { puts("  no resources defined"); return 0; }
        int cnt = detect(dead), v = -1, best = 1 << 30;
        if (!cnt) { puts("  no deadlock"); return 0; }
        printf("  DEADLOCK detected:"); 
        for (int p = 0; p < G.np; p++) if (dead[p]) {
            int h = 0; for (int r = 0; r < G.nres; r++) h += AL(p, r);
            printf(" P%d", p); if (h < best) { best = h; v = p; }
        }
        printf("\n  suggested victim: P%d (holds the fewest resources)\n", v);
        if (c[0] == 'r') { finish(v, 1); usleep(200000); cnt = detect(dead); printf("  after recovery: %s\n", cnt ? "still deadlocked" : "no deadlock"); }
    }
    else if (!strcmp(c, "banker")) { if (G.nres) banker(); else puts("  no resources defined"); }
    else if (!strcmp(c, "save")) { if (ac > 1 && save_state(av[1]) > 0) dlog("saved %s", av[1]); else puts("  usage: save <file>"); }
    else if (!strcmp(c, "load")) {
        int n = ac > 1 ? load_state(av[1]) : -1;
        if (n > 0) dlog("loaded %s (%d virtual processes)", av[1], n); else puts("  could not load file");
    }
    else if (!strcmp(c, "log")) print_log();
    else if (!strcmp(c, "stat")) { if (ac > 1) stat_file(av[1]); else puts("  usage: stat <file>"); }
    else if (!strcmp(c, "sh")) run_sh(av, ac);
    else if (!strcmp(c, "sys")) {
        struct utsname u; uname(&u); const char m[] = "  direct write() system call\n";
        fflush(stdout); syscall(SYS_write, 1, m, sizeof m - 1);
        printf("  kernel: %s %s (%s)\n  pid=%ld ppid=%d uid=%d\n", u.sysname, u.release, u.machine, syscall(SYS_getpid), getppid(), getuid());
    }
    else if (!strcmp(c, "maps")) show_maps();
    else if (!strcmp(c, "mem")) show_mem();
    else if (!strcmp(c, "cow")) cow_demo();
    else if (!strcmp(c, "faults")) fault_demo();
    else if (!strcmp(c, "race")) race_demo();
    else if (!strcmp(c, "fifo")) fifo_demo();
    else if (!strcmp(c, "demo")) demo();
    else printf("  unknown command '%s' (type help)\n", c);
    return 0;
}

int main(void) {
    setvbuf(stdout, NULL, _IOLBF, 0);
    board_init(); log_open(); sig_init(); sem_init(&G.slots, 0, MAXP);
    puts("Deadlock OS - Linux Deadlock Detection and Resource Management System\ntype 'help' or 'demo'");
    char line[256]; int tty = isatty(0);
    for (;;) {
        if (tty) { printf("dos> "); fflush(stdout); }
        if (!fgets(line, sizeof line, stdin)) break;
        if (!tty) printf("dos> %s", line);
        if (exec_line(line)) break;
    }
    kill_all(); puts("bye"); return 0;
}
