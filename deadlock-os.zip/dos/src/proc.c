/* proc.c - CO-2 process control and CO-3 IPC/signals (pipes, FIFO, handlers, groups) */
#include "dos.h"
const char *SN[] = { "free", "running", "WAITING", "done", "killed", "virtual" };

static int rl(int fd, char *b, int max) {  /* read one line from a pipe */
    int i = 0; char c;
    while (i < max - 1) {
        if (read(fd, &c, 1) <= 0) { b[i] = 0; return i ? i : -1; }
        if (c == '\n') break;
        b[i++] = c;
    }
    b[i] = 0; return i;
}

static void on_term(int s) {               /* child signal handler (async-signal-safe) */
    (void)s; static const char m[] = "  [child] caught SIGTERM: releasing resources, exiting\n";
    W(1, m, sizeof m - 1); _exit(0);
}
static void on_int(int s) { (void)s; static const char m[] = "\n  (Ctrl+C ignored, type quit to leave)\n"; W(1, m, sizeof m - 1); }

void sig_init(void) {
    struct sigaction sa; memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_int; sa.sa_flags = SA_RESTART; sigaction(SIGINT, &sa, NULL);
    signal(SIGPIPE, SIG_IGN);
}

static void child_main(int p, int rd, int wr) {      /* a simulated process */
    struct sigaction sa; memset(&sa, 0, sizeof sa);
    sa.sa_handler = on_term; sigaction(SIGTERM, &sa, NULL);
    signal(SIGINT, SIG_IGN);
    char b[64], o[64];
    for (;;) {
        if (rl(rd, b, sizeof b) < 0) _exit(0);
        if (!strncmp(b, "DO EXIT", 7)) _exit(0);
        B->st[p] = S_WAIT;                           /* shown as WAITING while blocked */
        int n = snprintf(o, sizeof o, "%s\n", b + 3);
        W(wr, o, n);                                 /* IPC: request to the manager */
        if (rl(rd, b, sizeof b) < 0) _exit(0);       /* blocks here until granted */
        B->st[p] = S_RUN;
    }
}

static void *worker(void *a) {             /* manager thread serving one process */
    int p = (int)(long)a; char b[64], op[8]; int r, n;
    while (rl(G.up[p], b, sizeof b) >= 0) {
        if (sscanf(b, "%7s %d %d", op, &r, &n) != 3 || r < 0 || r >= G.nres) continue;
        pthread_mutex_lock(&G.mu);
        if (!strcmp(op, "REQ")) {
            RQ(p, r) += n;
            while (!G.killed[p] && n > avail_of(r)) pthread_cond_wait(&G.cv, &G.mu);
            if (G.killed[p]) { pthread_mutex_unlock(&G.mu); break; }
            RQ(p, r) -= n; AL(p, r) += n;
            dlog("grant P%d <- %d x R%d", p, n, r);
        } else {
            if (AL(p, r) < n) n = AL(p, r);
            AL(p, r) -= n; dlog("free  P%d -> %d x R%d", p, n, r);
            pthread_cond_broadcast(&G.cv);
        }
        pthread_mutex_unlock(&G.mu);
        dprintf(G.down[p], "OK\n");
    }
    return NULL;
}

void sys_reset(int nres, const int *units) {
    kill_all();
    free(G.total); free(G.alloc); free(G.req); free(G.max);
    G.nres = nres; G.np = 0; G.pgid = 0;
    G.total = calloc(nres, sizeof(int)); G.alloc = calloc(MAXP * nres, sizeof(int));
    G.req = calloc(MAXP * nres, sizeof(int)); G.max = calloc(MAXP * nres, sizeof(int));
    memcpy(G.total, units, nres * sizeof(int));
    for (int p = 0; p < MAXP; p++) { G.killed[p] = 0; B->st[p] = S_FREE; G.down[p] = G.up[p] = -1; G.pid[p] = 0; }
    sem_destroy(&G.slots); sem_init(&G.slots, 0, MAXP);
}

int spawn(void) {                          /* CO-2: fork a simulated process */
    if (G.nres < 1) { puts("  define resources first: res <n> <units...>"); return -1; }
    if (G.np >= MAXP || sem_trywait(&G.slots)) { puts("  no free process slot (counting semaphore is 0)"); return -1; }
    int p = G.np, d[2], u[2];
    if (pipe(d) || pipe(u)) { perror("pipe"); return -1; }
    pid_t c = fork();
    if (c == 0) {
        for (int i = 0; i < p; i++) if (G.down[i] >= 0) { close(G.down[i]); close(G.up[i]); }
        close(d[1]); close(u[0]); setpgid(0, G.pgid);   /* join the simulation process group */
        child_main(p, d[0], u[1]);
    }
    close(d[0]); close(u[1]);
    if (!G.pgid) G.pgid = c;
    setpgid(c, G.pgid);
    G.pid[p] = c; G.down[p] = d[1]; G.up[p] = u[0]; G.killed[p] = 0; B->st[p] = S_RUN;
    pthread_create(&G.th[p], NULL, worker, (void *)(long)p);
    G.np++;
    dlog("spawned P%d (pid %d, group %d)", p, c, G.pgid);
    return p;
}

void send_do(int p, const char *op, int r, int n) { dprintf(G.down[p], "DO %s %d %d\n", op, r, n); }

void finish(int p, int killed) {           /* terminate (signal) or let the process exit */
    int st = B->st[p];
    if (st == S_VIRT) {
        pthread_mutex_lock(&G.mu);
        for (int r = 0; r < G.nres; r++) AL(p, r) = RQ(p, r) = 0;
        B->st[p] = S_KILLED; pthread_cond_broadcast(&G.cv); pthread_mutex_unlock(&G.mu);
        dlog("P%d (virtual) terminated; resources released", p); return;
    }
    if (st != S_RUN && st != S_WAIT) return;
    if (killed) kill(G.pid[p], SIGTERM); else send_do(p, "EXIT", 0, 0);
    waitpid(G.pid[p], NULL, 0);            /* reap: no zombie */
    pthread_mutex_lock(&G.mu);
    for (int r = 0; r < G.nres; r++) AL(p, r) = RQ(p, r) = 0;
    G.killed[p] = 1; B->st[p] = killed ? S_KILLED : S_DONE;
    pthread_cond_broadcast(&G.cv); pthread_mutex_unlock(&G.mu);
    pthread_join(G.th[p], NULL);
    close(G.down[p]); close(G.up[p]); G.down[p] = G.up[p] = -1;
    sem_post(&G.slots);
    dlog(killed ? "P%d killed (pid %d); resources released" : "P%d exited (pid %d)", p, G.pid[p]);
}

void kill_all(void) {                      /* one signal to the whole process group */
    int alive = 0;
    for (int p = 0; p < G.np; p++) if (B->st[p] == S_RUN || B->st[p] == S_WAIT) alive++;
    if (alive && G.pgid > 0) { dlog("kill(-%d, SIGTERM): signalling the process group", G.pgid); kill(-G.pgid, SIGTERM); usleep(150000); }
    for (int p = 0; p < G.np; p++)
        if (B->st[p] == S_RUN || B->st[p] == S_WAIT) finish(p, 1);
}

void ps(void) {
    printf("  %-5s %-7s %-9s %s\n", "ID", "PID", "STATE", "GROUP");
    for (int p = 0; p < G.np; p++) printf("  P%-4d %-7d %-9s %d\n", p, G.pid[p], SN[B->st[p]], G.pid[p] ? G.pgid : 0);
}

void fifo_demo(void) {                     /* CO-3: named pipe between unrelated-style processes */
    const char *path = "/tmp/deadlockos.fifo"; char b[64];
    unlink(path);
    if (mkfifo(path, 0600)) { perror("  mkfifo"); return; }
    pid_t c = fork();
    if (c == 0) { int fd = open(path, O_WRONLY); const char m[] = "message through a named pipe (FIFO)"; W(fd, m, sizeof m - 1); close(fd); _exit(0); }
    int fd = open(path, O_RDONLY); ssize_t k = read(fd, b, sizeof b - 1); close(fd);
    b[k > 0 ? k : 0] = 0; waitpid(c, NULL, 0); unlink(path);
    printf("  reader got: \"%s\"\n", b);
}
