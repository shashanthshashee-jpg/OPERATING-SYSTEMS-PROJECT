/* mem.c - CO-4: shared mmap memory, address space layout, COW, page faults */
#include "dos.h"
#include <sys/resource.h>
static int g_data = 42;
void board_init(void) {                    /* shared status board visible to all children */
    B = mmap(NULL, sizeof(Board), PROT_READ | PROT_WRITE, MAP_SHARED | MAP_ANONYMOUS, -1, 0);
    if (B == MAP_FAILED) { perror("mmap"); exit(1); }
}

void show_maps(void) {
    int local = 0; char *h = malloc(1024);
    printf("  code  %p\n  data  %p\n  heap  %p (malloc)\n  stack %p\n  mmap  %p (shared status board)\n",
           (void *)show_maps, (void *)&g_data, (void *)h, (void *)&local, (void *)B);
    free(h);
    FILE *f = fopen("/proc/self/maps", "r"); char ln[256];
    if (!f) return;
    puts("  /proc/self/maps (selected lines):");
    while (fgets(ln, sizeof ln, f))
        if (strstr(ln, "[heap]") || strstr(ln, "[stack]") || (strstr(ln, "r-xp") && strstr(ln, "deadlockos")))
            { fputs("    ", stdout); fputs(ln, stdout); }
    fclose(f);
}

void show_mem(void) {
    FILE *f = fopen("/proc/self/status", "r"); char ln[256];
    if (!f) return;
    while (fgets(ln, sizeof ln, f))
        if (!strncmp(ln, "VmSize", 6) || !strncmp(ln, "VmRSS", 5) || !strncmp(ln, "Threads", 7))
            { fputs("  ", stdout); fputs(ln, stdout); }
    fclose(f);
}

void cow_demo(void) {                      /* fork + copy-on-write */
    int x = 1; pid_t c = fork();
    if (c == 0) { char m[64]; x = 99; int n = snprintf(m, sizeof m, "  child : x=%d (private copy after write)\n", x); W(1, m, n); _exit(0); }
    waitpid(c, NULL, 0);
    printf("  parent: x=%d (unchanged, pages were copied on write)\n", x);
}

void fault_demo(void) {                    /* demand paging: pages load on first touch */
    struct rusage a, b; size_t sz = 8u << 20; volatile char *m = malloc(sz);
    getrusage(RUSAGE_SELF, &a);
    for (size_t i = 0; i < sz; i += 4096) m[i] = 1;
    getrusage(RUSAGE_SELF, &b);
    printf("  touched %zu pages of a fresh 8 MB block: %ld minor page faults\n", sz / 4096, b.ru_minflt - a.ru_minflt);
    free((void *)m);
}
