/* fileio.c - CO-5: file I/O system calls, log file, save/load, inode info */
#include "dos.h"
static int lfd = -1;
void log_open(void) { lfd = open("deadlockos.log", O_WRONLY | O_CREAT | O_APPEND, 0644); }

void dlog(const char *fmt, ...) {          /* unbuffered append to the log + screen */
    char b[200]; va_list a; va_start(a, fmt);
    int n = vsnprintf(b, sizeof b - 2, fmt, a); va_end(a);
    if (n > (int)sizeof b - 3) n = sizeof b - 3;
    b[n++] = '\n'; b[n] = 0;
    if (lfd >= 0) W(lfd, b, n);
    fputs("  ", stdout); fputs(b, stdout);
}

int save_state(const char *f) {            /* open + write + close */
    if (G.nres < 1) return -1;
    char b[2048]; int n = snprintf(b, sizeof b, "DEADLOCKOS 1\n%d %d\n", G.nres, G.np);
    pthread_mutex_lock(&G.mu);
    for (int r = 0; r < G.nres; r++) n += snprintf(b + n, sizeof b - n, "%d ", G.total[r]);
    b[n++] = '\n';
    int *m[3] = { G.alloc, G.req, G.max };
    for (int k = 0; k < 3; k++)
        for (int p = 0; p < G.np; p++) {
            for (int r = 0; r < G.nres; r++) n += snprintf(b + n, sizeof b - n, "%d ", m[k][p * G.nres + r]);
            b[n++] = '\n';
        }
    pthread_mutex_unlock(&G.mu);
    int fd = open(f, O_WRONLY | O_CREAT | O_TRUNC, 0644);
    if (fd < 0) return -1;
    W(fd, b, n); close(fd); return n;
}

int load_state(const char *f) {            /* open + read + parse */
    char b[4096] = {0}; int fd = open(f, O_RDONLY);
    if (fd < 0) return -1;
    ssize_t k = read(fd, b, sizeof b - 1); close(fd);
    if (k <= 0 || strncmp(b, "DEADLOCKOS 1\n", 13)) return -2;
    char *s = b + 13; int n, nres, np, units[16];
    if (sscanf(s, "%d %d%n", &nres, &np, &n) != 2 || nres < 1 || nres > 16 || np < 1 || np > MAXP) return -2;
    s += n;
    for (int r = 0; r < nres; r++) { if (sscanf(s, "%d%n", &units[r], &n) != 1) return -2; s += n; }
    sys_reset(nres, units); G.np = np;
    int *m[3] = { G.alloc, G.req, G.max };
    for (int k2 = 0; k2 < 3; k2++)
        for (int i = 0; i < np * nres; i++) { int v; if (sscanf(s, "%d%n", &v, &n) == 1) { m[k2][i] = v; s += n; } }
    for (int p = 0; p < np; p++) B->st[p] = S_VIRT;  /* virtual (offline) processes */
    return np;
}

void stat_file(const char *f) {            /* stat(): inode metadata */
    struct stat st;
    if (stat(f, &st)) { perror("  stat"); return; }
    printf("  %s: inode=%lu size=%ld bytes links=%lu mode=%o uid=%u\n", f,
           (unsigned long)st.st_ino, (long)st.st_size, (unsigned long)st.st_nlink,
           st.st_mode & 0777, st.st_uid);
}
